R1_OMA_1 = [];
R1_NOMA_1 = [];
R2_NOMA_1=[];
R2_OMA_1=[];
gamma_1_CSI_1 = 8;
gamma_2_CSI_1 = 2;
s_delta_1 = 1;
ASR1 = [];



R1_OMA_2 = [];
R1_NOMA_2 = [];
R2_NOMA_2=[];
R2_OMA_2=[];
gamma_1_CSI_2 = 8;
gamma_2_CSI_2 = 2;
s_delta_2 = (sinc(3.14*11/180))^2;
ASR2 = [];

for alpha1 = 0:0.2:1
    alpha2 = 1-alpha1;
    R2oma_1 = 0.5 * log2(1+gamma_2_CSI_1 * s_delta_1);  %R2_OMA
    R2oma_2 = 0.5 * log2(1+gamma_2_CSI_2 * s_delta_2);  %R2_OMA
    R2noma_1 = log2(1+(gamma_2_CSI_1 * alpha2 * s_delta_1/((gamma_2_CSI_1 * alpha1 * s_delta_1) + 1)));   %R2_NOMA
    R2noma_2 = log2(1+(gamma_2_CSI_2 * alpha2 * s_delta_2/((gamma_2_CSI_2 * alpha1 * s_delta_2) + 1)));   %R2_NOMA
    R2_NOMA_1=[R2_NOMA_1 R2noma_1];
    R2_OMA_1=[R2_OMA_1 R2oma_1];
    R2_NOMA_2=[R2_NOMA_2 R2noma_2];
    R2_OMA_2=[R2_OMA_2 R2oma_2];
    R1oma_1 = 0.5 * log2(1+gamma_1_CSI_1 * s_delta_1);  %R1_OMA
    R1oma_2 = 0.5 * log2(1+gamma_1_CSI_2 * s_delta_2);  %R1_OMA
    R1noma_1 = log2(1 + (alpha1 * gamma_1_CSI_1 * s_delta_1));   %R1_NOMA
    R1noma_2 = log2(1 + (alpha1 * gamma_1_CSI_2 * s_delta_2));   %R1_NOMA
    R1_NOMA_1=[R1_NOMA_1 R1noma_1];
    R1_OMA_1=[R1_OMA_1 R1oma_1];
    R1_NOMA_2=[R1_NOMA_2 R1noma_2];
    R1_OMA_2=[R1_OMA_2 R1oma_2];
    ASR1 = R1_NOMA_1 + R2_NOMA_1;
    ASR2 = R1_NOMA_2 + R2_NOMA_2;
    

end
alpha_lb_1 = (2^(R1oma_1) - 1)/(gamma_1_CSI_1 * s_delta_1);
alpha_ub_1 = ((gamma_2_CSI_1 * s_delta_1) - (2^(R2oma_1)-1))/(2^(R2oma_1) * gamma_2_CSI_1 * s_delta_1);

alpha_lb_2 = (2^(R1oma_1) - 1)/(gamma_1_CSI_2 * s_delta_2);
alpha_ub_2 = ((gamma_2_CSI_2 * s_delta_2) - (2^(R2oma_2)-1))/(2^(R2oma_2) * gamma_2_CSI_2 * s_delta_2);


alpha=0:0.2:1;
figure;
plot(alpha,R2_NOMA_1,'-+');
hold on
plot(alpha,R2_OMA_1,'-o');
hold on
plot(alpha,R1_NOMA_1,'->');
hold on
plot(alpha,R1_OMA_1,'-.^');
hold on
plot(alpha,ASR1,'-+');
hold on
xline(alpha_lb_1,'--o');
xline(alpha_ub_1);


legend('R2^{NOMA}','R2^{OMA}','R1^{NOMA}','R1^{OMA}','ASR_1','\alpha_{lb}','\alpha_{ub}')
xlabel('$\alpha_1$','Interpreter','Latex','FontSize',14,'FontName','TimesNewRoman');ylabel('Data Rate','FontSize',14,'FontName','TimesNewRoman');

alpha=0:0.2:1;
figure;
plot(alpha,R2_NOMA_2,'-+');  
hold on
plot(alpha,R2_OMA_2,'-o');
hold on
plot(alpha,R1_NOMA_2,'->');
hold on
plot(alpha,R1_OMA_2,'-.^');
hold on
plot(alpha,ASR1,'-+');
hold on
xline(alpha_lb_2,'--o');
xline(alpha_ub_2);
legend('R2^{NOMA}','R2^{OMA}','R1^{NOMA}','R1^{OMA}','ASR_2','\alpha_{lb}','\alpha_{ub}')
xlabel('$\alpha_1$','Interpreter','Latex','FontSize',14,'FontName','TimesNewRoman');ylabel('Data Rate','FontSize',14,'FontName','TimesNewRoman');


R1_OMA_1 = [];
R1_NOMA_1 = [];
R2_NOMA_1=[];
R2_OMA_1=[];
gamma_1_CSI_1 = 8;
gamma_2_CSI_1 = 2;
ASR1 = [];
alpha1 = 0.2;
alpha2 = 0.8;



R1_OMA_2 = [];
R1_NOMA_2 = [];
R2_NOMA_2=[];
R2_OMA_2=[];
gamma_1_CSI_2 = 8;
gamma_2_CSI_2 = 5;
ASR2 = [];

for delta = 0:2:20
    R2oma_1 = 0.990326;  %R2_OMA -1st
    R2oma_2 = 0.5 * log2(1+(gamma_2_CSI_2 * (sinc(3.14*delta/180))^2));  %R2_OMA -2nd
    R2noma_1 = log2(1+(gamma_2_CSI_1 * alpha2 * (sinc(3.14*delta/180))^2/((gamma_2_CSI_1 * alpha1 * (sinc(3.14*delta/180))^2) + 1)));   %R2_NOMA -1st
    R2noma_2 = log2(1+(gamma_2_CSI_2 * alpha2 * (sinc(3.14*delta/180))^2/((gamma_2_CSI_2 * alpha1 * (sinc(3.14*delta/180))^2) + 1)));   %R2_NOMA -2nd
    R2_NOMA_1=[R2_NOMA_1 R2noma_1]; 
    R2_OMA_1=[R2_OMA_1 R2oma_1];
    R2_NOMA_2=[R2_NOMA_2 R2noma_2];
    R2_OMA_2=[R2_OMA_2 R2oma_2];
    R1oma_1 =1.20769;  %R1_OMA -1st
    R1oma_2 = 0.5 * log2(1+gamma_1_CSI_2 * (sinc(3.14*delta/180))^2);  %R1_OMA -2nd
    R1noma_1 = log2(1 + (alpha1 * gamma_1_CSI_1 * (sinc(3.14*delta/180))^2));   %R1_NOMA -1st
    R1noma_2 = log2(1 + (alpha1 * gamma_1_CSI_2 * (sinc(3.14*delta/180))^2));   %R1_NOMA -2nd
    R1_NOMA_1=[R1_NOMA_1 R1noma_1];
    R1_OMA_1=[R1_OMA_1 R1oma_1];
    R1_NOMA_2=[R1_NOMA_2 R1noma_2];
    R1_OMA_2=[R1_OMA_2 R1oma_2];
end
%%s_delta_up_1 = sqrt(((2^R1oma_1 - 1)/(gamma_1_CSI_1)) + ((2^R2oma_1 - 1)/(gamma_2_CSI_1)));
%%s_delta_up_2 = sqrt(((2^R1oma_2 - 1)/(gamma_1_CSI_2)) + ((2^R2oma_2 - 1)/(gamma_2_CSI_2)));
%%syms s_delta_up_1;
%sol1=double(solve(sinc(s_delta_up_1)==0.11));
%syms s_delta_up_2
%sol2=double(solve(sinc(s_delta_up_2)==0.11))
delta=0:2:20;
figure;
plot(delta,R2_NOMA_1,'-+');
hold on
plot(delta,R2_OMA_1,'-o');
hold on
plot(delta,R1_NOMA_1,'->');
hold on
plot(delta,R1_OMA_1,'-.^');
hold on
xline(14);
legend('R2^{NOMA}','R2^{OMA}','R1^{NOMA}','R1^{OMA}')
xlabel('$\delta$','Interpreter','Latex','FontSize',14,'FontName','TimesNewRoman');ylabel('Data Rate','FontSize',14,'FontName','TimesNewRoman');

